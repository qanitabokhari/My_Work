<?php include "conn.php"?>

<!doctype html>
<html lang="en">

<head>
    <title>Work Details</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.6.2/css/all.min.css"
    integrity="sha512-g0gRzvKX9GBUbjlJZ02n2GLRJVabgLm6b3oypbkF6ne1T2+ZHCucKRd8qt31a3BCGahAlBmXUDS7lu2pYuWB7A=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">
            <img src="sign-language.png" width="35" height="35" class="d-inline-block align-top" alt="">
            Pakistan Sign Language
        </a>
        <form class="form-inline">
            <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">

        </form>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <div class="mr-auto"></div>
            <ul class="navbar-nav my-2 my-lg-0">
                <li class="nav-item active">
                    <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link btn btn-block btn-primary" href="#"><i class="fas fa-sign-in-alt"></i> Login</a>
                </li>

            </ul>

        </div>
    </nav>

    <?php 
    $subcat = $_GET['subcat'];
    $sql = "select * from work_detail where sub_cat_name = '$subcat'";
    $r = $conn->query($sql);
    while($row=mysqli_fetch_assoc($r)){
        $a = $row['actual_video'];
        $g = $row['generated_video'];
        $h = $row['hamnosys'];
    }
  ?>
    <?php 
    $subcat = $_GET['subcat'];
    $sql1 = "select * from sub_category where name = '$subcat'";
    $r1 = $conn->query($sql1);
    while($row1=mysqli_fetch_assoc($r1)){
        $cat = $row1['cat'];
    }
  ?>
    <div class="container-fluid mt-5">
        <div class="container">
            <h1><i class="fa fa-word"></i> English: <?php echo $subcat;?></h1>
            <h1><i class="fa fa-word"></i> Urdu: </h1>
            <p>Category : <strong><i><?php echo $cat;?></i></strong></p>
        </div>
        <hr>
        <?php 
            if(empty($a) || empty($g)){
        ?>
        <h1 class="text-center">No Data Found !!</h1>
        <h1 class="text-center"><a href="index.php" class="lead text-dark"><i class="fas fa-backward"></i> Back To Main Page</a></h1>
        <?php }else{?>
        <div class="row">
            <div class="col-md-4">
                <div class="tile card text-center">
                    <p><strong><i>Actual Video</i></strong></p>
                    <div class="tile-body">
                        <video width="90%" controls>
                            <source src=https://pakistan-sign-language.digital/psl-corpus/<?php echo $a;?>
                                type="video/mp4">
                            <source src=https://pakistan-sign-language.digital/psl-corpus/uploads/<?php echo $a;?>
                                type="video/mov">
                            Your browser does not support HTML5 video.
                        </video>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="tile card text-center">
                    <p><strong><i>Genrated Video</i></strong></p>
                    <div class="tile-body">
                        <video width="90%" controls>
                            <source src=https://pakistan-sign-language.digital/psl-corpus/<?php echo $g;?>
                                type="video/mp4">
                            <source src=https://pakistan-sign-language.digital/psl-corpus/<?php echo $g;?>
                                type="video/mov">
                            Your browser does not support HTML5 video.
                        </video>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="tile">
                    <p><strong><i>HamNoSys</i></strong></p>
                    <textarea style="overflow: hidden;" disable id="myP" rows="5" cols="50">
          <?php echo $h;?>
            </textarea>

                </div>
            </div>
        </div>
        <?php }?>
    </div>
    </div>
    <br><br>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous">
    </script>
</body>

</html>