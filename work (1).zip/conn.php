<?php $conn = mysqli_connect("localhost", "root", "", "pak_sign_lan"); ?>
<?php if (!$conn) {
  echo "<h1>Failed to Connect to Database!</h1>";
}?>
