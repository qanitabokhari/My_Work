<?php 
include "conn.php";
session_start();

if(isset($_POST['submit'])){
  $icon = $_POST['icon'];
  $name = $_POST['cname'];

  $sql = "insert into category(icon,name) values('$icon','$name')";
  $result=$conn->query($sql);
  if($result){
    $_SESSION['msg'] = "Category Added Successfully!";
    header("location:project.php");
    die();
  }
  else{
    $_SESSION['msg'] = "Unable to Add Category";
  }

}


?>

<?php 
if(isset($_POST['subcat'])){
  $icon = $_POST['icon'];
  $name = $_POST['cname'];
  $cat = $_POST['cat'];

  $sql = "insert into sub_category(icon,name,cat) values('$icon','$name','$cat')";
  $result=$conn->query($sql);
  if($result){
    $_SESSION['msg'] = "Sub Category Added Successfully!";
    header("location:project.php");
    die();
  }
  else{
    $_SESSION['msg'] = "Unable to Add Category";
  }

}


?>
<?php 
if(isset($_POST['link'])){
  $sub = $_POST['sub_cat'];
  $avideo = $_POST['avideo'];
  $gvideo = $_POST['gvideo'];
  $hom = $_POST['hymnosis'];

  $sql = "insert into work_detail(sub_cat_name,actual_video,generated_video,hamnosys) values('$sub','$avideo','$gvideo','$hom')";
  $result=$conn->query($sql);
  if($result){
    $_SESSION['msg'] = "Video Links Added Successfully!";
    header("location:project.php");
    die();
  }
  else{
    $_SESSION['msg'] = "Unable to Add Video Links";
  }

}


?>

<?php 
if(isset($_GET['delete'])){
  $id = $_GET['delete'];
  $sql = "delete from category where id = '$id'";
  $result = $conn->query($sql);
  if($result){
    $_SESSION['msg'] = "Category Deleted Successfully";
    header("location:project.php");
    die();
  }
  else{
    $_SESSION['msg'] = "Unable to Delete Category";
  }
}


?>
<?php 
if(isset($_GET['deletes'])){
  $id = $_GET['deletes'];
  $sql = "delete from sub_category where id = '$id'";
  $result = $conn->query($sql);
  if($result){
    $_SESSION['msg'] = "Sub Category Deleted Successfully";
    header("location:project.php");
    die();
  }
  else{
    $_SESSION['msg'] = "Unable to Delete Sub Category";
  }
}


?>

<?php 
if(isset($_GET['deletev'])){
  $id = $_GET['deletev'];
  $sql = "delete from work_detail where id = '$id'";
  $result = $conn->query($sql);
  if($result){
    $_SESSION['msg'] = "Video Links Deleted Successfully";
    header("location:project.php");
    die();
  }
  else{
    $_SESSION['msg'] = "Unable to Delete Video Links";
  }
}


?>

<!doctype html>
<html lang="en">

<head>
  <title>Admin</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.6.2/css/all.min.css"
    integrity="sha512-g0gRzvKX9GBUbjlJZ02n2GLRJVabgLm6b3oypbkF6ne1T2+ZHCucKRd8qt31a3BCGahAlBmXUDS7lu2pYuWB7A=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
    integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>

<body>
  <div class="container-fluid mt-5">
    <h3 class="text-success text-center">
      <?php if(isset($_SESSION['msg'])){echo $_SESSION['msg'];}unset($_SESSION['msg']);?></h3>
    <div class="row">
      <div class="col-md-4">
        <h1 class="text-center">Add Category</h1>
        <form action="#" method="POST" enctype="multipart/form-data">
          <div class="form-group row">
            <label for="inputEmail3" class="col-sm-2 col-form-label">Icon</label>
            <div class="col-12">
              <input type="text" class="form-control" name="icon" id="inputEmail3" placeholder="Category Icon" required>
            </div>
          </div>
          <div class="form-group row">
            <label for="inputPassword3" class="col-sm-2 col-form-label">Name</label>
            <div class="col-12">
              <input type="text" name="cname" class="form-control" id="chooseFile" placeholder="Category Name" required>
            </div>
          </div>
          <div class="form-group row">
            <div class="col-12">
              <button type="submit" name="submit" class="btn btn-primary btn-block">Submit</button>
            </div>
          </div>

        </form>
      </div>
      <div class="col-md-4">
        <h1 class="text-center">Add Sub Category</h1>
        <form action="#" method="POST" enctype="multipart/form-data">
          <div class="form-group row">
            <label for="inputEmail3" class="col-sm-2 col-form-label">Icon</label>
            <div class="col-12">
              <input type="text" class="form-control" name="icon" id="inputEmail3" placeholder="Category Icon">
            </div>
          </div>
          <div class="form-group row">
            <label for="inputPassword3" class="col-sm-2 col-form-label">Name</label>
            <div class="col-12">
              <input type="text" name="cname" class="form-control" id="chooseFile" placeholder="Category Name" required>
            </div>
          </div>
          <div class="form-group row">
            <label for="inputPassword3" class="col-sm-2 col-form-label">Category</label>
            <div class="col-12">
              <select name="cat" id="">
                <?php 
      $sql = "select * from category";
      $r = $conn->query($sql);
      while($row=mysqli_fetch_assoc($r)){
      ?>
                <option value="<?php echo $row['name']?>"><?php echo $row['name']?></option>
                <?php }?>
              </select>
            </div>
          </div>
          <div class="form-group row">
            <div class="col-12">
              <button type="submit" name="subcat" class="btn btn-primary btn-block">Submit</button>
            </div>
          </div>

        </form>
      </div>
      <div class="col-md-4">
        <h1 class="text-center">Add Links</h1>
        <form action="#" method="POST" enctype="multipart/form-data">
          <div class="row">
            <div class="form-group col-6">
              <label for="inputPassword3" class="col-sm-2 col-form-label">Category</label><br>
              <select name="cat" id="">
                <?php 
      $sql = "select * from category";
      $r = $conn->query($sql);
      while($row=mysqli_fetch_assoc($r)){
      ?>
                <option value="<?php echo $row['name']?>"><?php echo $row['name']?></option>
                <?php }?>
              </select>
            </div>
            <div class="form-group col-6">
              <label for="inputPassword3" class="col-sm-2 col-form-label" style="text">Sub_Category</label><br>
              <select name="sub_cat" id="">
                <?php 
      $sql = "select * from sub_category";
      $r = $conn->query($sql);
      while($row=mysqli_fetch_assoc($r)){
      ?>
                <option value="<?php echo $row['name']?>"><?php echo $row['name']?></option>
                <?php }?>
              </select>
            </div>
            <div class="form-group col-12">
              <label for="inputPassword3" class="col-sm-2 col-form-label">Actual</label>
              <input type="text" name="avideo" class="form-control" id="chooseFile" placeholder="Actual Video Link"
                required>
            </div>
            <div class="form-group col-12">
              <label for="inputPassword3" class="col-sm-2 col-form-label">Generated</label>
              <input type="text" name="gvideo" class="form-control" id="chooseFile" placeholder="Generated Video Link"
                required>
            </div>
            <div class="form-group col-12">
              <label for="inputPassword3" class="col-sm-2 col-form-label">HymNoSys</label>
              <input type="text" name="hymnosis" class="form-control" id="chooseFile" placeholder="HymNoSys" required>
            </div>

            <div class="form-group">
              <div class="col-12">
                <button type="submit" name="link" class="btn btn-primary btn-block">Submit</button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
    </div>
    <br><br><br>
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-6">
          <h1 class="text-center">Categories</h1>
          <table class="table table-dark">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Category Icon</th>
                <th scope="col">Category Name</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>
              <?php 
                $sql = "select * from category";
                $result=$conn->query($sql);
                while($row=mysqli_fetch_assoc($result)){
                  $id = $row['id'];
                  $icon = $row['icon'];
                  $name = $row['name'];
              ?>
              <tr>
                <th scope="row"><?php echo $id;?></th>
                <td><i class="<?php echo $row['icon'];?> fa-2x"></i></td>
                <td><?php echo $name;?></td>
                <td><a href="?delete=<?php echo $id;?>"><button class="btn btn-block btn-danger">Delete</button></a>
                </td>
              </tr>
              <?php }?>
            </tbody>
          </table>
        </div>
        <div class="col-md-6">
          <h1 class="text-center">Sub Categories</h1>
          <table class="table table-dark">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Sub Icon</th>
                <th scope="col">Sub Name</th>
                <th scope="col">Category Name</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>
              <?php 
                $sql = "select * from sub_category";
                $result=$conn->query($sql);
                while($row=mysqli_fetch_assoc($result)){
                  $id = $row['id'];
                  $icon = $row['icon'];
                  $name = $row['name'];
              ?>
              <tr>
                <th scope="row"><?php echo $id;?></th>
                <td><i class="<?php echo $row['icon'];?> fa-2x"></i></td>
                <td><?php echo $name;?></td>
                <td><?php echo $row['cat'];?></td>
                <td><a href="?deletes=<?php echo $id;?>"><button class="btn btn-block btn-danger">Delete</button></a>
                </td>
              </tr>
              <?php }?>
            </tbody>
          </table>
        </div>
        <div class="col-md-12">
          <h1 class="text-center">Links</h1>
          <table class="table table-dark">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Sub Category</th>
                <th scope="col">Actual</th>
                <th scope="col">Generated</th>
                <th scope="col">HamNoSys</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>
              <?php 
                $sql = "select * from work_detail";
                $result=$conn->query($sql);
                while($row=mysqli_fetch_assoc($result)){
                  $id = $row['id'];
                  $sub = $row['sub_cat_name'];
                  $a = $row['actual_video'];
                  $g = $row['generated_video'];
                  $h = $row['hamnosys'];
              ?>
              <tr>
                <th scope="row"><?php echo $id;?></th>
                <td><?php echo $sub;?></td>
                <td><?php echo $a;?></td>
                <td><?php echo $g;?></td>
                <td><?php echo $h;?></td>
                <td><a href="?deletes=<?php echo $id;?>"><button class="btn btn-block btn-danger">Delete</button></a>
                </td>
              </tr>
              <?php }?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  <!-- Optional JavaScript -->
  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
    integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
  </script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
    integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous">
  </script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
    integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous">
  </script>
</body>

</html>